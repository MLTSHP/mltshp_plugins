#MLKSHK Firefox Add-On

Adds a contextual menu item that allows you to right-click on an image and add it to your shake.